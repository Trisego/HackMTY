const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const mysql = require('mysql2/promise'); // Use mysql2 with promise support
require('dotenv').config();





const config = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
};

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
  const connection = await mysql.createConnection(config);
  try {
    const [rows] = await connection.execute('SELECT * FROM users WHERE id = ?', [id]);
    done(null, rows[0]);
  } catch (err) {
    done(err);
  } finally {
    await connection.end();
  }
});

passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: process.env.NODE_ENV === 'production' 
    ? 'https://ebooksai.xyz/auth/google/callback' 
    : 'http://localhost:3000/auth/google/callback'
  },
  async (accessToken, refreshToken, profile, cb) => {
    const connection = await mysql.createConnection(config);
    try {
      // Check if user already exists
      const [rows] = await connection.execute('SELECT * FROM users WHERE google_id = ?', [profile.id]);
      if (rows.length > 0) {
        return cb(null, rows[0]);
      } else {
        // Insert new user
        const [result] = await connection.execute(
          'INSERT INTO users (email, google_id, name, credits) VALUES (?, ?, ?, ?)',
          [profile.emails[0].value, profile.id, profile.displayName, 5]
        );
        const [user] = await connection.execute('SELECT * FROM users WHERE id = ?', [result.insertId]);
        return cb(null, user[0]);
      }
    } catch (err) {
      return cb(err);
    } finally {
      await connection.end();
    }
  }
));



module.exports = passport;
