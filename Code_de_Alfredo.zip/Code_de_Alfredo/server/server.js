require('dotenv').config(); // Load environment variables from .env file
console.log(process.env.PORT);

const bcrypt = require('bcrypt');
const {insertGeneration} = require('./mysql.js');
const express = require('express');
const axios = require('axios');
const multer = require('multer');
const cors = require('cors'); // Import the CORS package
const FormData = require('form-data');
const session = require('express-session');
const Sequelize = require('sequelize');
const SequelizeStore = require('connect-session-sequelize')(session.Store);
const passport = require('./passport-config');
const mysql = require('mysql2/promise');
const bodyParser = require('body-parser');
const validator = require('validator');
const rateLimit = require('express-rate-limit');
const path = require('path');
// const { RecaptchaEnterpriseServiceClient } = require('@google-cloud/recaptcha-enterprise');





const API_KEY = process.env.API_KEY; // Define API_KEY constant
const CONVERT_API_SECRET = process.env.CONVERT_API_SECRET; // Define CONVERT_API_SECRET constant

const app = express();  
app.disable('x-powered-by');  
const port = process.env.PORT ?? 3000;

const config = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
};


app.use(bodyParser.urlencoded({ extended: true })); // For parsing application/x-www-form-urlencoded
app.use(bodyParser.json());

// Middleware to parse JSON bodies
app.use(express.json());


app.use(express.static('public'));


app.use(express.static(path.join(__dirname, 'public')));

// Enable CORS for all routes
app.use(cors());

// Configure multer storage
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });



/*
// Set up session middleware
app.use((req, res, next) => {
  console.log('Session Middleware - Initializing...');
  console.log('Secure Cookie:', process.env.NODE_ENV === 'production');
  console.log('Session ID before session middleware:', req.sessionID);
  next();
});
*/



const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
  host: process.env.DB_HOST,
  dialect: 'mysql'
});

const store = new SequelizeStore({
  db: sequelize
});
// Sync the session store
store.sync().then(() => {
  store.startExpiringSessions(); // Ensure expired sessions are cleaned up
});

app.set('trust proxy', 1);

// Set up session middleware
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  store: store,
  cookie: {
    secure: process.env.NODE_ENV === 'production', // Use 'true' in production to ensure cookies are sent over HTTPS
    httpOnly: true, // Prevents client-side JavaScript from accessing the cookie 
    sameSite: 'strict',
     maxAge: 1000 * 60 * 60 * 3// Session expires after 3 HOURS
  }
}));

store.sync(); // Create the sessions table if it doesn't exist

// Initialize passport and session
app.use(passport.initialize());
app.use(passport.session());

/*
// Log session information after middleware initialization
app.use((req, res, next) => {
  console.log('Session Middleware - After Initialization...');
  console.log('Session ID:', req.sessionID);
  console.log('Session Data:', req.session);
  next();
});


// Example route to test session functionality
app.get('/test-session', (req, res) => {
  if (!req.session.views) {
    req.session.views = 1;
  } else {
    req.session.views++;
  }
  console.log('Session Data on /test-session:', req.session);
  res.send(`Number of views: ${req.session.views}`);
});
*/

// Middleware to check if the user is authenticated
function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect('/auth.html');
}


app.get('/', (req, res) => {
  res.render('auth');
});


app.get('/logout', (req, res) => {
  req.logout((err) => {
    if (err) { return next(err); }
    res.redirect('/auth.html');
  });
});

//register
app.post('/register', async (req, res) => {
  const { username, email, password, recaptchaResponse } = req.body;

  if (!recaptchaResponse) {
      return res.status(400).send('reCAPTCHA is required.');
  }

  // Verifica el token de reCAPTCHA con la API de Google
  try {
      const secretKey = process.env.CAPTCHA_SECRET;
      const verificationUrl = `https://www.google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${recaptchaResponse}`;

      
      
      console.log('reCAPTCHA verified successfully');

      // Verifica email y contraseña como en tu código actual
      if (!validator.isEmail(email)) {
          return res.status(400).send('Invalid email format.');
      }

      if (!password || password.length < 6) {
          return res.status(400).send('Password must be at least 6 characters long.');
      }

      const connection = await mysql.createConnection(config);

      // Verifica si el correo electrónico ya está registrado
      const [rows] = await connection.execute('SELECT email FROM users WHERE email = ?', [email]);
      if (rows.length > 0) {
          await connection.end();
          return res.status(400).send('Email is already registered.');
      }

      // Verifica si el nombre de usuario ya está en uso
      const [userRows] = await connection.execute('SELECT name FROM users WHERE name = ?', [username]);
      if (userRows.length > 0) {
          await connection.end();
          return res.status(400).send('Username is already taken.');
      }
      
      const { data } = await axios.post(verificationUrl);
      if (!data.success) {
          return res.status(400).send('Failed reCAPTCHA verification.');
      }

      // Cifra la contraseña y registra al usuario
      const hashedPassword = await bcrypt.hash(password, 10);
      await connection.execute(
          'INSERT INTO users (name, email, password, credits) VALUES (?, ?, ?, ?)',
          [username, email, hashedPassword, 5]
      );
      
      const [newUser] = await connection.execute('SELECT * FROM users WHERE email = ?', [email]);
      await connection.end();

      req.login(newUser[0], (err) => {
          if (err) return next(err);
          res.status(200).send('User registered and logged in successfully.');
      });

  } catch (err) {
      console.error('Error verifying reCAPTCHA or registering user:', err);
      res.status(500).send('Error occurred while registering new user.');
  }
});

// Rate limiter middleware to limit repeated login attempts
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 login requests per windowMs
  message: 'Account locked due to multiple failed login attempts. Please try again later.'
});

app.post('/login', loginLimiter, async (req, res, next) => {
  const { email, password } = req.body;

  try {
    const connection = await mysql.createConnection(config);
    const [rows] = await connection.execute('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      await connection.end();
      return res.status(400).send('Invalid email or password.');
    }

    const user = rows[0];
    if (user.google_id && !user.password) {
      await connection.end();
      return res.status(400).send('This email is registered via Google. Please use Google login.');
    }

    if (user.failed_login_attempts >= 5) {
      await connection.end();
      return res.status(403).send('Account locked due to multiple failed login attempts. Please try again later.');
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      await connection.execute('UPDATE users SET failed_login_attempts = failed_login_attempts + 1 WHERE id = ?', [user.id]);
      await connection.end();
      return res.status(400).send('Invalid email or password.');
    }

    // Reset failed login attempts on successful login
    await connection.execute('UPDATE users SET failed_login_attempts = 0 WHERE id = ?', [user.id]);

    await connection.end();

    req.login(user, (err) => {
      if (err) return next(err);
      res.status(200).send('User logged in successfully.');
    });
  } catch (err) {
    console.error('Error logging in:', err);
    res.status(500).send('Error occurred while logging in.');
  }
});

// Protect the app.html route
app.get('/app.html', ensureAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'app.html'));
});


app.get('/api/user', ensureAuthenticated, (req, res) => {
  res.json(req.user);
});

app.get('/api/check-auth', (req, res) => {
  if (req.isAuthenticated()) {
    res.json({ authenticated: true });
  } else {
    res.json({ authenticated: false });
  }
});

app.post('/students', ensureAuthenticated, async (req, res) => {
  const { name, age, gender, hobbies, passions, grade_level, best_friend_name, favorite_food, additional_info } = req.body;

  if (!name || !age || !gender || !grade_level) {
    return res.status(400).send('Name, age, gender, and grade level are required fields.');
  }

  try {
    const connection = await mysql.createConnection(config);

    // Insert the new student into the students table
    const [result] = await connection.execute(
      `INSERT INTO students (user_id, name, age, gender, hobbies, passions, grade_level, best_friend_name, favorite_food, additional_info) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        req.user.id, // The authenticated teacher's user_id
        name,
        age,
        gender,
        hobbies || null,
        passions || null,
        grade_level,
        best_friend_name || null,
        favorite_food || null,
        additional_info || null
      ]
    );

    await connection.end();

    // Respond with a success message
    res.status(200).send('Student added successfully.');
  } catch (err) {
    console.error('Error adding student:', err);
    res.status(500).send('Error occurred while adding the student.');
  }
});

// Route to fetch students for the authenticated teacher
app.get('/api/students', ensureAuthenticated, async (req, res) => {
  try {
    const connection = await mysql.createConnection(config);
    
    // Retrieve students for the authenticated teacher, including id and name
    const [rows] = await connection.execute(
      'SELECT id, name FROM students WHERE user_id = ?',
      [req.user.id]
    );

    await connection.end();

    // Respond with the list of students
    res.json(rows); // Ensure the response contains both id and name
  } catch (err) {
    console.error('Error fetching students:', err);
    res.status(500).send('Error occurred while fetching students.');
  }
});

app.get('/api/students/:id', ensureAuthenticated, async (req, res) => {
  const studentId = req.params.id;

  try {
    const connection = await mysql.createConnection(config);

    // Retrieve the specific student by ID and ensure they belong to the authenticated user
    const [rows] = await connection.execute(
      'SELECT * FROM students WHERE id = ? AND user_id = ?',
      [studentId, req.user.id]
    );

    await connection.end();

    if (rows.length === 0) {
      return res.status(404).send('Student not found.');
    }

    // Respond with the student's details
    res.json(rows[0]);
  } catch (err) {
    console.error('Error fetching student details:', err);
    res.status(500).send('Error occurred while fetching student details.');
  }
});

// Route to update a student's details by ID
app.put('/api/students/:id', ensureAuthenticated, async (req, res) => {
  const studentId = req.params.id;
  const { name, age, gender, hobbies, passions, grade_level, best_friend_name, favorite_food, additional_info } = req.body;

  if (!name || !age || !gender || !grade_level) {
    return res.status(400).send('Name, age, gender, and grade level are required fields.');
  }

  try {
    const connection = await mysql.createConnection(config);

    // Update the student's details, but only if the student belongs to the authenticated user
    const [result] = await connection.execute(
      `UPDATE students 
       SET name = ?, age = ?, gender = ?, hobbies = ?, passions = ?, grade_level = ?, best_friend_name = ?, favorite_food = ?, additional_info = ?
       WHERE id = ? AND user_id = ?`,
      [
        name,
        age,
        gender,
        hobbies || null,
        passions || null,
        grade_level,
        best_friend_name || null,
        favorite_food || null,
        additional_info || null,
        studentId,
        req.user.id // Ensure the user is only updating their own students
      ]
    );

    await connection.end();

    if (result.affectedRows === 0) {
      return res.status(404).send('Student not found or you are not authorized to update this student.');
    }

    res.status(200).send('Student updated successfully.');
  } catch (err) {
    console.error('Error updating student:', err);
    res.status(500).send('Error occurred while updating the student.');
  }
});


async function fetchWithRetry(url, options, retries = 3, delay = 3000) {
    try {
      const response = await axios(url, options);
      if (response.status !== 200) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response;
    } catch (error) {
      if (retries === 0) {
        throw error;
      }
      console.warn(`Retrying after ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return fetchWithRetry(url, options, retries - 1, delay * 2);
    }
  }


// Define the getTitle function
async function getTitle(topic, selectedLanguage) {
  try {
    const responseTitle = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: "gpt-3.5-turbo",
        messages: [{
          role: "user",
          content: "give me a title for a book about " + topic + ". without quotation marks, just the title. Don't Make the title too long. Don't use colons or semicolons. Write it in" + selectedLanguage
        }],
        max_tokens: 20,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${API_KEY}`, // Use the API_KEY constant
        },
      }
    );

    const data = responseTitle.data;
    return data.choices[0].message.content.replaceAll("\"", "");
  } catch (error) {
    console.error("Error getting title:", error);
    return "Error occurred while getting title.";
  }
}

// Endpoint to generate title
app.post('/generate-title', async (req, res) => {
  const { topic, selectedLanguage} = req.body;

  if (!topic) {
    return res.status(400).send('Prompt is required');
  }

  try {
    const title = await getTitle(topic, selectedLanguage);
    res.json({ title });
  } catch (error) {
    res.status(500).send('An error occurred while generating the title');
  }
});


// Endpoint to get chapters
app.post('/get-chapters', async (req, res) => {
    const { title, topic, selectedLanguage } = req.body;
  
    if (!title || !topic) {
      return res.status(400).send('title and topic are required');
    }
  
    try {
      const responseChapters = await fetchWithRetry(`https://api.openai.com/v1/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${API_KEY}`,
        },
        data: JSON.stringify({
          model: "gpt-3.5-turbo",
          messages: [{
            role: "user",
            content: `Give me a list of chapters for a book titled ${title}. This is a book about ${topic}, give me only the list of the names of the chapters. without subtitles or numbers. Wirte them in  ${selectedLanguage}`
          }],
          max_tokens: 150,
        }),
      });
  
      const data = responseChapters.data;
      res.json(data.choices[0].message.content);
    } catch (error) {
      console.error("Error getting chapters:", error);
      res.status(500).send("Error occurred while getting chapters.");
    }
  });


// Endpoint to generate full chapters
app.post('/generate-chapters', async (req, res) => {
    const { title, topic, chapterNamesArray, selectedLanguage } = req.body;
  
    if (!title || !topic || !chapterNamesArray || !Array.isArray(chapterNamesArray)) {
      return res.status(400).send('Title, topic, and an array of chapter names are required');
    }
  
    const chapterContentsArray = [];
  
   //for (let i = 0; i < chapterNamesArray.length; i++) {
   for (let i = 0; i < 2; i++) {
      try {
        const responseChapter = await fetchWithRetry(`https://api.openai.com/v1/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${API_KEY}`,
          },
          data: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [{
              role: "user",
              content: `Write only the contents of a full chapter called ${chapterNamesArray[i]} in a book titled ${title}, and it is a book about ${topic}. This is chapter number ${i + 1}. Write everything in ${selectedLanguage}`
            }],
            max_tokens: 2000,
          }),
        });
  
        const data = responseChapter.data;
        let chapterContent = data.choices[0].message.content;
  
        let lines = chapterContent.split("\n");
  
        // Remove the first line (chapter numbering and title) if it exists
        if (lines.length > 1) {
          lines.shift();
        }
  
        // Join the remaining lines back into a single string
        chapterContent = lines.join("\n");
  
        chapterContentsArray.push(chapterContent);
      } catch (error) {
        console.error(`Error generating chapter ${i + 1}:`, error);
        chapterContentsArray.push(`Error generating chapter ${i + 1}: ${error.message}`);
      }
    }
  
    res.json(chapterContentsArray);
  });


  
// Endpoint to get template choice
app.post('/get-choice', async (req, res) => {
    const { title, chapters } = req.body;
  
    if (!title || !chapters) {
      return res.status(400).send('Title and chapters are required');
    }
  
    const validTemplates = [
      'modern_minimalist.docx',
      'women.docx',
      'wellness_diet.docx',
      'classic_literature.docx',
      'romance.docx',
      'fitness.docx',
    ];
  
    let attempts = 0;
    let invalidTemplateName = null;
  
    while (attempts < 5) {
      try {
        let prompt = `I am making an ebook, and I have all the contents available, but I need help choosing a template for the book. The title of the book is '${title}', and the chapters are the following: ${chapters}. I have 14 choices for templates. 
        'classic_literature.docx' has a beige background with dark brown text and maroon accents. Ideal for traditional literature and historical topics. 
        'modern_minimalist.docx' has a white background with black text and light gray accents. Suitable for modern and minimalist content. 
        'women.docx' has pink colors and is ideal for content for women.
        'romance.docx' has a light pink or ivory background with dark red or brown text and gold or deep red accents. Ideal for romance novels and love stories. 
        'wellness_diet.docx' has a light green background with dark green text and white accents. Perfect for wellness, health, and diet-related content. 
        'fitness.docx' has a light gray or white background with black text and bright blue and orange accents. Best for fitness guides and exercise books. 
  
        Reply with the name of the best template only, and nothing else.
        It has to be a template name I've given you, NOTHING ELSE, the options are: 'classic_literature.docx',
        'modern_minimalist.docx',
        'women.docx',
        'wellness_diet.docx',
        'classic_literature.docx',
        'romance.docx',   
        'fitness.docx',
       `;
  
        if (invalidTemplateName) {
          prompt += ` The name CANNOT be ${invalidTemplateName}.`;
        }
  
        const responseChoice = await fetchWithRetry(`https://api.openai.com/v1/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${API_KEY}`,
          },
          data: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [{
              role: "user",
              content: prompt
            }],
            max_tokens: 100,
          }),
        });
  
        const data = responseChoice.data;
        const returnedTemplate = data.choices[0].message.content.trim();
        const match = returnedTemplate.match(/[a-z_]+\.docx/i)?.[0];
  
        // Check if the returned template is in the valid templates list
        if (validTemplates.includes(match)) {
          return res.json({ template: match });
        } else {
          console.warn(`Invalid template returned: ${match}. Retrying...`);
          invalidTemplateName = match;  // Store the invalid template name for exclusion
        }
      } catch (error) {
        console.error("Error getting Choice:", error);
        return res.status(500).send("Error occurred while getting Choice.");
      }
  
      attempts++;
    }
  
    res.status(500).send("Error: Could not get a valid template after multiple attempts.");
  });



  
// Endpoint to convert DOCX to PDF
app.post('/convert-docx-to-pdf', upload.single('file'), async (req, res) => {
  const docxFile = req.file;

  if (!docxFile) {
    return res.status(400).send("No file uploaded.");
  }

  // Validate the file type
  if (docxFile.mimetype !== 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    return res.status(400).send("Invalid file type. Please upload a DOCX file.");
  }

  const form = new FormData();
  form.append('file', docxFile.buffer, { filename: docxFile.originalname, contentType: docxFile.mimetype });

  try {
    const response = await axios.post(
      `https://v2.convertapi.com/convert/docx/to/pdf?Secret=${CONVERT_API_SECRET}`,
      form,
      { headers: form.getHeaders() }
    );

    const data = response.data;
    console.log('ConvertAPI response:', data);

    // Validate the API response structure
    if (!data || !data.Files || !data.Files[0] || !data.Files[0].FileData) {
      throw new Error('Invalid response structure from ConvertAPI');
    }

    const base64Pdf = data.Files[0].FileData;
    const buffer = Buffer.from(base64Pdf, 'base64');

    res.contentType('application/pdf');
    res.send(buffer);
  } catch (error) {
    console.error("Error during DOCX to PDF conversion:", error);

    if (error.response && error.response.data) {
      console.error("ConvertAPI Error response:", error.response.data);
    }

    res.status(500).send("Error occurred while converting DOCX to PDF.");
  }
});



app.post('/insert-generation', ensureAuthenticated, async (req, res) => {
  const { title, topic, template, type } = req.body;
  const user = req.user; // Access the authenticated user's data from the session

  if (!title || !topic || !template || !type) {
    return res.status(400).send('Title, topic, type, and template are required');
  }

  try {
    const result = await insertGeneration(title, topic, template, user.id, type); // Pass user ID to the function
    res.json({ success: true, result });
  } catch (error) {
    console.error('Error inserting generation:', error);
    res.status(500).send('An error occurred while inserting generation data');
  }
});

function getRandomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

app.post('/generate-schema-array', async (req, res) => {
  const { chapterNamesArray, topic, title, selectedLanguage } = req.body;

  if (!chapterNamesArray || !topic || !title) {
    return res.status(400).send('chapterNamesArray, topic, and title are required');
  }

  try {
    const schemaArray = await Promise.all(chapterNamesArray.map(async (chapterName) => {
      const randNumber = getRandomNumber(2, 5);

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${API_KEY}`,
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [{
            role: 'user',
            content: `Given the topic "${topic}" and the book title "${title}", suggest ${randNumber} possible topics for the chapter titled "${chapterName}" Don't write the topics too long. Write it in ${selectedLanguage}`,
          }],
          max_tokens: 150,
        }),
      });

      const data = await response.json();
      return data.choices[0].message.content.split('\n').filter(Boolean);
    }));
    res.json(schemaArray);
  } catch (error) {
    console.error('Error generating schema array:', error);
    res.status(500).send('Error occurred while generating schema array.');
  }
});

app.post('/generate-content-array', async (req, res) => {
  const { schemaArray, topic, title, chapterNamesArray, selectedLanguage } = req.body;

  if (!schemaArray || !topic || !title || !chapterNamesArray || !selectedLanguage) {
    return res.status(400).send('schemaArray, topic, title, chapterNamesArray, and selectedLanguage are required');
  }

  try {
    const contentArray = await Promise.all(schemaArray.map(async (chapterTopics, chapterIndex) => {
      const chapterContents = await Promise.all(chapterTopics.map(async (topic) => {
        const payload = {
          model: 'gpt-3.5-turbo',
          messages: [{
            role: 'user',
            content: `Write detailed content for the topic "${topic}" within the chapter titled "${chapterNamesArray[chapterIndex]}" in the book "${title}" on the subject of "${topic}". Don't add labels in the beginning of the contents. For example, don't say "introduction: .....". Write it in ${selectedLanguage}`,
          }],
          max_tokens: 50, // Adjust as needed
        };

       // console.log('Sending payload to OpenAI:', JSON.stringify(payload, null, 2));

        const response = await fetchWithRetry('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${API_KEY}`,
          },
          data: payload,
        });

        const data = await response.data;
       // console.log('Received response from OpenAI:', JSON.stringify(data, null, 2));

        if (!data.choices || !data.choices[0] || !data.choices[0].message) {
          throw new Error('Invalid response from OpenAI');
        }

        return data.choices[0].message.content;
      }));

      return chapterContents;
    }));

    res.json({ contentArray });
  } catch (error) {
    console.error('Error generating content array:', error.message);
    res.status(500).send('Error occurred while generating content array.');
  }
});


app.post('/deduct-credits', ensureAuthenticated, async (req, res) => {
  const userId = req.user.id; // Assuming you store the user ID in the session
  const { amount } = req.body;

  try {
    const connection = await mysql.createConnection(config);

    // Subtract credits
    const [result] = await connection.execute('UPDATE users SET credits = credits - ? WHERE id = ? AND credits >= ?', [amount, userId, amount]);

    if (result.affectedRows === 0) {
      await connection.end();
      return res.json({ success: false, message: 'Not enough credits' });
    }

    // Get the updated credit balance
    const [rows] = await connection.execute('SELECT credits FROM users WHERE id = ?', [userId]);
    const updatedCredits = rows[0].credits;

    await connection.end();
    
    // Return the updated credits
    res.json({ success: true, message: 'Credits updated successfully', credits: updatedCredits });
  } catch (error) {
    console.error('Error updating credits:', error);
    res.status(500).json({ success: false, message: 'Error occurred while updating credits' });
  }
});

app.post('/add-credits', ensureAuthenticated, async (req, res) => {
  const userId = req.user.id; // Assuming you store the user ID in the session
  const { amount } = req.body;

  try {
    const connection = await mysql.createConnection(config);

    // Add credits
    const [result] = await connection.execute('UPDATE users SET credits = credits + ? WHERE id = ?', [amount, userId]);

    // Get the updated credit balance
    const [rows] = await connection.execute('SELECT credits FROM users WHERE id = ?', [userId]);
    const updatedCredits = rows[0].credits;

    await connection.end();
    
    // Return the updated credits
    res.json({ success: true, message: 'Credits added successfully', credits: updatedCredits });
  } catch (error) {
    console.error('Error adding credits:', error);
    res.status(500).json({ success: false, message: 'Error occurred while adding credits' });
  }
});

app.get('/api/latest-ebooks', async (req, res) => {
  try {
    const connection = await mysql.createConnection(config);
    
    const query = `
      SELECT eg.title, eg.topic, eg.date, u.name as created_by
      FROM ebooks_generated eg
      JOIN users u ON eg.user = u.id
      ORDER BY eg.date DESC
      LIMIT 5
    `;
    
    const [rows] = await connection.execute(query);
    await connection.end();

    res.json(rows);
  } catch (error) {
    console.error('Error fetching latest eBooks:', error);
    res.status(500).json({ success: false, message: 'Error occurred while fetching latest eBooks' });
  }
});





// Start the server
app.listen(port, () => {
  console.log(`Server is running on ${port}`);
});



